
import Foundation

public class GridScheduleResult{

    var name = ""
    var gridChannels = [GridChannel]()
    var startDate = ""
    var locale = ""
    var build = ""
    var requestId = ""
    var timeStamp = ""
    var duration = -1
    var endTimestamp = ""
    var timeZones = [TimeZone]()
    var serviceId = -1
    var status = ""
    var errors = [Int]()


    init(){

    }

    init?(JSON:AnyObject?){
        var json = JSON
        if json != nil{
            if json is [String:AnyObject]{
                if let firstKey = (json as! [String:AnyObject]).keys.first{
                    if firstKey == "GridScheduleResult"{
                        json = json![firstKey]
                    }
                }

                guard
                    let name = json?["Name"] as? String,
                    let gridChannels = json?["GridChannels"] as? [[String:AnyObject]],
                    let startDate = json?["StartDate"] as? String,
                    let locale = json?["Locale"] as? String,
                    let build = json?["Build"] as? String,
                    let requestId = json?["RequestId"] as? String,
                    let timeStamp = json?["TimeStamp"] as? String,
                    let duration = json?["Duration"] as? Int,
                    let endTimestamp = json?["EndTimestamp"] as? String,
                    let timeZones = json?["TimeZones"] as? [[String:AnyObject]],
                    let serviceId = json?["ServiceId"] as? Int,
                    let status = json?["Status"] as? String,
                    let errors = json?["Errors"] as? [Int]
                else{
                    return nil
                }

                self.name = name
                self.gridChannels = GridChannel.fromJSONArray(gridChannels)
                self.startDate = startDate
                self.locale = locale
                self.build = build
                self.requestId = requestId
                self.timeStamp = timeStamp
                self.duration = duration
                self.endTimestamp = endTimestamp
                self.timeZones = TimeZone.fromJSONArray(timeZones)
                self.serviceId = serviceId
                self.status = status
                self.errors = errors


            }
            else{
                return nil
            }
        }
        else{
            return nil
        }
    }

    class func fromJSONArray(JSON:[[String:AnyObject]]) -> [GridScheduleResult]{
        var returnArray = [GridScheduleResult]()
        for entry in JSON{
            if let ent = GridScheduleResult(JSON: entry){
                returnArray.append(ent)
            }
        }
        return returnArray
    }

    private func traverseJSON(inout gridScheduleResults:[GridScheduleResult], JSON:AnyObject, complete:((gridScheduleResults:[GridScheduleResult])->())?){
        if JSON is [String:AnyObject]{
            for (_,v) in (JSON as! [String:AnyObject]){
                if v is [String:AnyObject]{
                    if let attempt = GridScheduleResult(JSON: v as! [String:AnyObject]){
                        gridScheduleResults.append(attempt)
                    }
                    traverseJSON(&gridScheduleResults, JSON: v as! [String:AnyObject], complete: nil)
                }
                else if v is [[String:AnyObject]]{
                    traverseJSON(&gridScheduleResults, JSON: v as! [[String:AnyObject]], complete: nil)
                }
            }
        }
        else if JSON is [[String:AnyObject]]{
            for entry in (JSON as! [[String:AnyObject]]){
                if let attempt = GridScheduleResult(JSON: entry){
                    gridScheduleResults.append(attempt)
                }
                else{
                    traverseJSON(&gridScheduleResults, JSON: entry, complete: nil)
                }
            }
        }
        if complete != nil{
            complete!(gridScheduleResults: gridScheduleResults)
        }
    }

    func findInJSON(JSON:AnyObject, complete:((gridScheduleResults:[GridScheduleResult])->())?){
        var gridScheduleResults = [GridScheduleResult]()
        traverseJSON(&gridScheduleResults, JSON: JSON) { (gridScheduleResults) in
            if complete != nil{
                complete!(gridScheduleResults: gridScheduleResults)
            }
        }
    }

}

extension GridScheduleResult{
    var toJSON: [String:AnyObject] {
        var jsonObject = [String:AnyObject]()
        jsonObject["name"] = self.name
        jsonObject["gridChannels"] = self.gridChannels.toJSONArray
        jsonObject["startDate"] = self.startDate
        jsonObject["locale"] = self.locale
        jsonObject["build"] = self.build
        jsonObject["requestId"] = self.requestId
        jsonObject["timeStamp"] = self.timeStamp
        jsonObject["duration"] = self.duration
        jsonObject["endTimestamp"] = self.endTimestamp
        jsonObject["timeZones"] = self.timeZones.toJSONArray
        jsonObject["serviceId"] = self.serviceId
        jsonObject["status"] = self.status
        jsonObject["errors"] = self.errors

        return jsonObject
    }

    var toJSONString: String {
        var jsonString = ""
        jsonString += ", \"name\":\"\(self.name)\""
        jsonString += ", \"gridChannels\":\"\(self.gridChannels.toJSONString)\""
        jsonString += ", \"startDate\":\"\(self.startDate)\""
        jsonString += ", \"locale\":\"\(self.locale)\""
        jsonString += ", \"build\":\"\(self.build)\""
        jsonString += ", \"requestId\":\"\(self.requestId)\""
        jsonString += ", \"timeStamp\":\"\(self.timeStamp)\""
        jsonString += ", \"duration\":\"\(self.duration)\""
        jsonString += ", \"endTimestamp\":\"\(self.endTimestamp)\""
        jsonString += ", \"timeZones\":\"\(self.timeZones.toJSONString)\""
        jsonString += ", \"serviceId\":\"\(self.serviceId)\""
        jsonString += ", \"status\":\"\(self.status)\""
        jsonString += ", \"errors\":\"\(self.errors)\""

        jsonString = String(jsonString.characters.dropFirst()) //removes the ','
        jsonString = String(jsonString.characters.dropFirst()) //removes the beginning space

        return jsonString
    }
}

extension Array where Element:GridScheduleResult{
    var toJSONArray : [[String:AnyObject]]{
        var returnArray = [[String:AnyObject]]()
        for entry in self{
            returnArray.append(entry.toJSON)
        }
        return returnArray
    }

    var toJSONString : String{
        var returnString = ""
        for entry in self{
            returnString += entry.toJSONString
        }
        return returnString
    }
}

public class GridChannel{

    var sourceType = ""
    var channelSchedules = [Int]()
    var parentNetworkId = -1
    var sourceAttributes = ""
    var type = ""
    var sourceId = -1
    var iconAvailable = false
    var displayName = ""
    var channel = ""
    var channelImages : [ChannelImage]? = nil
    var isChannelOverride = false
    var order = -1
    var serviceId = -1
    var airings : [Airing]? = nil
    var callLetters = ""
    var sourceLongName = ""

    var sourceAttributeTypes : SourceAttributeType? = nil

    init(){

    }

    init?(JSON:AnyObject?){
        var json = JSON
        if json != nil{
            if json is [String:AnyObject]{
                if let firstKey = (json as! [String:AnyObject]).keys.first{
                    if firstKey == "GridChannel"{
                        json = json![firstKey]
                    }
                }

                guard
                    let sourceType = json?["SourceType"] as? String,
                    let channelSchedules = json?["ChannelSchedules"] as? [Int],
                    let parentNetworkId = json?["ParentNetworkId"] as? Int,
                    let sourceAttributes = json?["SourceAttributes"] as? String,
                    let type = json?["Type"] as? String,
                    let sourceId = json?["SourceId"] as? Int,
                    let iconAvailable = json?["IconAvailable"] as? Bool,
                    let displayName = json?["DisplayName"] as? String,
                    let channel = json?["Channel"] as? String,
                    let isChannelOverride = json?["IsChannelOverride"] as? Bool,
                    let order = json?["Order"] as? Int,
                    let serviceId = json?["ServiceId"] as? Int,
                    let callLetters = json?["CallLetters"] as? String,
                    let sourceLongName = json?["SourceLongName"] as? String
                else{
                    return nil
                }

                self.sourceType = sourceType
                self.channelSchedules = channelSchedules
                self.parentNetworkId = parentNetworkId
                self.sourceAttributes = sourceAttributes
                self.type = type
                self.sourceId = sourceId
                self.iconAvailable = iconAvailable
                self.displayName = displayName
                self.channel = channel
                self.isChannelOverride = isChannelOverride
                self.order = order
                self.serviceId = serviceId
                self.callLetters = callLetters
                self.sourceLongName = sourceLongName

                if let channelImages = json?["ChannelImages"] as? [[String:AnyObject]]{
                    self.channelImages = ChannelImage.fromJSONArray(channelImages)
                }
                if let airings = json?["Airings"] as? [[String:AnyObject]]{
                    self.airings = Airing.fromJSONArray(airings)
                }


            }
            else{
                return nil
            }
        }
        else{
            return nil
        }
    }

    class func fromJSONArray(JSON:[[String:AnyObject]]) -> [GridChannel]{
        var returnArray = [GridChannel]()
        for entry in JSON{
            if let ent = GridChannel(JSON: entry){
                returnArray.append(ent)
            }
        }
        return returnArray
    }

    private func traverseJSON(inout gridChannels:[GridChannel], JSON:AnyObject, complete:((gridChannels:[GridChannel])->())?){
        if JSON is [String:AnyObject]{
            for (_,v) in (JSON as! [String:AnyObject]){
                if v is [String:AnyObject]{
                    if let attempt = GridChannel(JSON: v as! [String:AnyObject]){
                        gridChannels.append(attempt)
                    }
                    traverseJSON(&gridChannels, JSON: v as! [String:AnyObject], complete: nil)
                }
                else if v is [[String:AnyObject]]{
                    traverseJSON(&gridChannels, JSON: v as! [[String:AnyObject]], complete: nil)
                }
            }
        }
        else if JSON is [[String:AnyObject]]{
            for entry in (JSON as! [[String:AnyObject]]){
                if let attempt = GridChannel(JSON: entry){
                    gridChannels.append(attempt)
                }
                else{
                    traverseJSON(&gridChannels, JSON: entry, complete: nil)
                }
            }
        }
        if complete != nil{
            complete!(gridChannels: gridChannels)
        }
    }

    func findInJSON(JSON:AnyObject, complete:((gridChannels:[GridChannel])->())?){
        var gridChannels = [GridChannel]()
        traverseJSON(&gridChannels, JSON: JSON) { (gridChannels) in
            if complete != nil{
                complete!(gridChannels: gridChannels)
            }
        }
    }

}

extension GridChannel{
    var toJSON: [String:AnyObject] {
        var jsonObject = [String:AnyObject]()
        jsonObject["sourceType"] = self.sourceType
        jsonObject["channelSchedules"] = self.channelSchedules
        jsonObject["parentNetworkId"] = self.parentNetworkId
        jsonObject["sourceAttributes"] = self.sourceAttributes
        jsonObject["type"] = self.type
        jsonObject["sourceId"] = self.sourceId
        jsonObject["iconAvailable"] = self.iconAvailable
        jsonObject["displayName"] = self.displayName
        jsonObject["channel"] = self.channel
        jsonObject["isChannelOverride"] = self.isChannelOverride
        jsonObject["order"] = self.order
        jsonObject["serviceId"] = self.serviceId
        jsonObject["callLetters"] = self.callLetters
        jsonObject["sourceLongName"] = self.sourceLongName

        if self.channelImages != nil{
            jsonObject["channelImages"] = self.channelImages!.toJSONArray
        }
        if self.airings != nil{
            jsonObject["airings"] = self.airings!.toJSONArray
        }

        return jsonObject
    }

    var toJSONString: String {
        var jsonString = ""
        jsonString += ", \"sourceType\":\"\(self.sourceType)\""
        jsonString += ", \"channelSchedules\":\"\(self.channelSchedules)\""
        jsonString += ", \"parentNetworkId\":\"\(self.parentNetworkId)\""
        jsonString += ", \"sourceAttributes\":\"\(self.sourceAttributes)\""
        jsonString += ", \"type\":\"\(self.type)\""
        jsonString += ", \"sourceId\":\"\(self.sourceId)\""
        jsonString += ", \"iconAvailable\":\"\(self.iconAvailable)\""
        jsonString += ", \"displayName\":\"\(self.displayName)\""
        jsonString += ", \"channel\":\"\(self.channel)\""
        jsonString += ", \"isChannelOverride\":\"\(self.isChannelOverride)\""
        jsonString += ", \"order\":\"\(self.order)\""
        jsonString += ", \"serviceId\":\"\(self.serviceId)\""
        jsonString += ", \"callLetters\":\"\(self.callLetters)\""
        jsonString += ", \"sourceLongName\":\"\(self.sourceLongName)\""

        if self.channelImages != nil{
            jsonString += ", \"channelImages\":\"\(self.channelImages!.toJSONString)\""
        }
        if self.airings != nil{
            jsonString += ", \"airings\":\"\(self.airings!.toJSONString)\""
        }

        jsonString = String(jsonString.characters.dropFirst()) //removes the ','
        jsonString = String(jsonString.characters.dropFirst()) //removes the beginning space

        return jsonString
    }
}

extension Array where Element:GridChannel{
    var toJSONArray : [[String:AnyObject]]{
        var returnArray = [[String:AnyObject]]()
        for entry in self{
            returnArray.append(entry.toJSON)
        }
        return returnArray
    }

    var toJSONString : String{
        var returnString = ""
        for entry in self{
            returnString += entry.toJSONString
        }
        return returnString
    }
}

public class TimeZone{

    var offset = -1
    var startDateTime = ""
    var endDateTime = ""


    init(){

    }

    init?(JSON:AnyObject?){
        var json = JSON
        if json != nil{
            if json is [String:AnyObject]{
                if let firstKey = (json as! [String:AnyObject]).keys.first{
                    if firstKey == "TimeZone"{
                        json = json![firstKey]
                    }
                }

                guard
                    let offset = json?["Offset"] as? Int,
                    let startDateTime = json?["StartDateTime"] as? String,
                    let endDateTime = json?["EndDateTime"] as? String
                else{
                    return nil
                }

                self.offset = offset
                self.startDateTime = startDateTime
                self.endDateTime = endDateTime


            }
            else{
                return nil
            }
        }
        else{
            return nil
        }
    }

    class func fromJSONArray(JSON:[[String:AnyObject]]) -> [TimeZone]{
        var returnArray = [TimeZone]()
        for entry in JSON{
            if let ent = TimeZone(JSON: entry){
                returnArray.append(ent)
            }
        }
        return returnArray
    }

    private func traverseJSON(inout timeZones:[TimeZone], JSON:AnyObject, complete:((timeZones:[TimeZone])->())?){
        if JSON is [String:AnyObject]{
            for (_,v) in (JSON as! [String:AnyObject]){
                if v is [String:AnyObject]{
                    if let attempt = TimeZone(JSON: v as! [String:AnyObject]){
                        timeZones.append(attempt)
                    }
                    traverseJSON(&timeZones, JSON: v as! [String:AnyObject], complete: nil)
                }
                else if v is [[String:AnyObject]]{
                    traverseJSON(&timeZones, JSON: v as! [[String:AnyObject]], complete: nil)
                }
            }
        }
        else if JSON is [[String:AnyObject]]{
            for entry in (JSON as! [[String:AnyObject]]){
                if let attempt = TimeZone(JSON: entry){
                    timeZones.append(attempt)
                }
                else{
                    traverseJSON(&timeZones, JSON: entry, complete: nil)
                }
            }
        }
        if complete != nil{
            complete!(timeZones: timeZones)
        }
    }

    func findInJSON(JSON:AnyObject, complete:((timeZones:[TimeZone])->())?){
        var timeZones = [TimeZone]()
        traverseJSON(&timeZones, JSON: JSON) { (timeZones) in
            if complete != nil{
                complete!(timeZones: timeZones)
            }
        }
    }

}

extension TimeZone{
    var toJSON: [String:AnyObject] {
        var jsonObject = [String:AnyObject]()
        jsonObject["offset"] = self.offset
        jsonObject["startDateTime"] = self.startDateTime
        jsonObject["endDateTime"] = self.endDateTime

        return jsonObject
    }

    var toJSONString: String {
        var jsonString = ""
        jsonString += ", \"offset\":\"\(self.offset)\""
        jsonString += ", \"startDateTime\":\"\(self.startDateTime)\""
        jsonString += ", \"endDateTime\":\"\(self.endDateTime)\""

        jsonString = String(jsonString.characters.dropFirst()) //removes the ','
        jsonString = String(jsonString.characters.dropFirst()) //removes the beginning space

        return jsonString
    }
}

extension Array where Element:TimeZone{
    var toJSONArray : [[String:AnyObject]]{
        var returnArray = [[String:AnyObject]]()
        for entry in self{
            returnArray.append(entry.toJSON)
        }
        return returnArray
    }

    var toJSONString : String{
        var returnString = ""
        for entry in self{
            returnString += entry.toJSONString
        }
        return returnString
    }
}

public class Error{



    init(){

    }

    init?(JSON:AnyObject?){
        var json = JSON
        if json != nil{
            if json is [String:AnyObject]{
                if let firstKey = (json as! [String:AnyObject]).keys.first{
                    if firstKey == "Error"{
                        json = json![firstKey]
                    }
                }


            }
            else{
                return nil
            }
        }
        else{
            return nil
        }
    }

    class func fromJSONArray(JSON:[[String:AnyObject]]) -> [Error]{
        var returnArray = [Error]()
        for entry in JSON{
            if let ent = Error(JSON: entry){
                returnArray.append(ent)
            }
        }
        return returnArray
    }

    private func traverseJSON(inout errors:[Error], JSON:AnyObject, complete:((errors:[Error])->())?){
        if JSON is [String:AnyObject]{
            for (_,v) in (JSON as! [String:AnyObject]){
                if v is [String:AnyObject]{
                    if let attempt = Error(JSON: v as! [String:AnyObject]){
                        errors.append(attempt)
                    }
                    traverseJSON(&errors, JSON: v as! [String:AnyObject], complete: nil)
                }
                else if v is [[String:AnyObject]]{
                    traverseJSON(&errors, JSON: v as! [[String:AnyObject]], complete: nil)
                }
            }
        }
        else if JSON is [[String:AnyObject]]{
            for entry in (JSON as! [[String:AnyObject]]){
                if let attempt = Error(JSON: entry){
                    errors.append(attempt)
                }
                else{
                    traverseJSON(&errors, JSON: entry, complete: nil)
                }
            }
        }
        if complete != nil{
            complete!(errors: errors)
        }
    }

    func findInJSON(JSON:AnyObject, complete:((errors:[Error])->())?){
        var errors = [Error]()
        traverseJSON(&errors, JSON: JSON) { (errors) in
            if complete != nil{
                complete!(errors: errors)
            }
        }
    }

}

extension Error{
    var toJSON: [String:AnyObject] {
        var jsonObject = [String:AnyObject]()
        return jsonObject
    }

    var toJSONString: String {
        var jsonString = ""

        return jsonString
    }
}

extension Array where Element:Error{
    var toJSONArray : [[String:AnyObject]]{
        var returnArray = [[String:AnyObject]]()
        for entry in self{
            returnArray.append(entry.toJSON)
        }
        return returnArray
    }

    var toJSONString : String{
        var returnString = ""
        for entry in self{
            returnString += entry.toJSONString
        }
        return returnString
    }
}

public class ChannelSchedule{



    init(){

    }

    init?(JSON:AnyObject?){
        var json = JSON
        if json != nil{
            if json is [String:AnyObject]{
                if let firstKey = (json as! [String:AnyObject]).keys.first{
                    if firstKey == "ChannelSchedule"{
                        json = json![firstKey]
                    }
                }


            }
            else{
                return nil
            }
        }
        else{
            return nil
        }
    }

    class func fromJSONArray(JSON:[[String:AnyObject]]) -> [ChannelSchedule]{
        var returnArray = [ChannelSchedule]()
        for entry in JSON{
            if let ent = ChannelSchedule(JSON: entry){
                returnArray.append(ent)
            }
        }
        return returnArray
    }

    private func traverseJSON(inout channelSchedules:[ChannelSchedule], JSON:AnyObject, complete:((channelSchedules:[ChannelSchedule])->())?){
        if JSON is [String:AnyObject]{
            for (_,v) in (JSON as! [String:AnyObject]){
                if v is [String:AnyObject]{
                    if let attempt = ChannelSchedule(JSON: v as! [String:AnyObject]){
                        channelSchedules.append(attempt)
                    }
                    traverseJSON(&channelSchedules, JSON: v as! [String:AnyObject], complete: nil)
                }
                else if v is [[String:AnyObject]]{
                    traverseJSON(&channelSchedules, JSON: v as! [[String:AnyObject]], complete: nil)
                }
            }
        }
        else if JSON is [[String:AnyObject]]{
            for entry in (JSON as! [[String:AnyObject]]){
                if let attempt = ChannelSchedule(JSON: entry){
                    channelSchedules.append(attempt)
                }
                else{
                    traverseJSON(&channelSchedules, JSON: entry, complete: nil)
                }
            }
        }
        if complete != nil{
            complete!(channelSchedules: channelSchedules)
        }
    }

    func findInJSON(JSON:AnyObject, complete:((channelSchedules:[ChannelSchedule])->())?){
        var channelSchedules = [ChannelSchedule]()
        traverseJSON(&channelSchedules, JSON: JSON) { (channelSchedules) in
            if complete != nil{
                complete!(channelSchedules: channelSchedules)
            }
        }
    }

}

extension ChannelSchedule{
    var toJSON: [String:AnyObject] {
        var jsonObject = [String:AnyObject]()
        return jsonObject
    }

    var toJSONString: String {
        var jsonString = ""

        return jsonString
    }
}

extension Array where Element:ChannelSchedule{
    var toJSONArray : [[String:AnyObject]]{
        var returnArray = [[String:AnyObject]]()
        for entry in self{
            returnArray.append(entry.toJSON)
        }
        return returnArray
    }

    var toJSONString : String{
        var returnString = ""
        for entry in self{
            returnString += entry.toJSONString
        }
        return returnString
    }
}

public class ChannelImage{

    var imageFormatId = ""
    var imageId = ""
    var imageVerticalResolution = ""
    var objectType = ""
    var imageType = ""
    var objectId = ""
    var parentImageId = ""
    var imageURL = ""
    var imageCreditDisplay = ""
    var imageCaption = ""
    var imageFormat : String? = nil
    var imageHorizontalResolution = ""
    var lastUpdate = ""
    var objectName = ""
    var imageTitle = ""
    var imageExpiryDateTime : String? = nil //**This was actually undefined--being set to String by default**
    var aspectRatio = ""
    var imageOwner : String? = nil
    var imageCredit : String? = nil


    init(){

    }

    init?(JSON:AnyObject?){
        var json = JSON
        if json != nil{
            if json is [String:AnyObject]{
                if let firstKey = (json as! [String:AnyObject]).keys.first{
                    if firstKey == "ChannelImage"{
                        json = json![firstKey]
                    }
                }

                guard
                    let imageFormatId = json?["ImageFormatId"] as? String,
                    let imageId = json?["ImageId"] as? String,
                    let imageVerticalResolution = json?["ImageVerticalResolution"] as? String,
                    let objectType = json?["ObjectType"] as? String,
                    let imageType = json?["ImageType"] as? String,
                    let objectId = json?["ObjectId"] as? String,
                    let parentImageId = json?["ParentImageId"] as? String,
                    let imageURL = json?["ImageURL"] as? String,
                    let imageCreditDisplay = json?["ImageCreditDisplay"] as? String,
                    let imageCaption = json?["ImageCaption"] as? String,
                    let imageHorizontalResolution = json?["ImageHorizontalResolution"] as? String,
                    let lastUpdate = json?["LastUpdate"] as? String,
                    let objectName = json?["ObjectName"] as? String,
                    let imageTitle = json?["ImageTitle"] as? String,
                    let aspectRatio = json?["AspectRatio"] as? String
                else{
                    return nil
                }

                self.imageFormatId = imageFormatId
                self.imageId = imageId
                self.imageVerticalResolution = imageVerticalResolution
                self.objectType = objectType
                self.imageType = imageType
                self.objectId = objectId
                self.parentImageId = parentImageId
                self.imageURL = imageURL
                self.imageCreditDisplay = imageCreditDisplay
                self.imageCaption = imageCaption
                self.imageHorizontalResolution = imageHorizontalResolution
                self.lastUpdate = lastUpdate
                self.objectName = objectName
                self.imageTitle = imageTitle
                self.aspectRatio = aspectRatio

                if let imageFormat = json?["ImageFormat"] as? String{
                    self.imageFormat = imageFormat
                }
                if let imageExpiryDateTime = json?["ImageExpiryDateTime"] as? String{
                    self.imageExpiryDateTime = imageExpiryDateTime
                }
                if let imageOwner = json?["ImageOwner"] as? String{
                    self.imageOwner = imageOwner
                }
                if let imageCredit = json?["ImageCredit"] as? String{
                    self.imageCredit = imageCredit
                }


            }
            else{
                return nil
            }
        }
        else{
            return nil
        }
    }

    class func fromJSONArray(JSON:[[String:AnyObject]]) -> [ChannelImage]{
        var returnArray = [ChannelImage]()
        for entry in JSON{
            if let ent = ChannelImage(JSON: entry){
                returnArray.append(ent)
            }
        }
        return returnArray
    }

    private func traverseJSON(inout channelImages:[ChannelImage], JSON:AnyObject, complete:((channelImages:[ChannelImage])->())?){
        if JSON is [String:AnyObject]{
            for (_,v) in (JSON as! [String:AnyObject]){
                if v is [String:AnyObject]{
                    if let attempt = ChannelImage(JSON: v as! [String:AnyObject]){
                        channelImages.append(attempt)
                    }
                    traverseJSON(&channelImages, JSON: v as! [String:AnyObject], complete: nil)
                }
                else if v is [[String:AnyObject]]{
                    traverseJSON(&channelImages, JSON: v as! [[String:AnyObject]], complete: nil)
                }
            }
        }
        else if JSON is [[String:AnyObject]]{
            for entry in (JSON as! [[String:AnyObject]]){
                if let attempt = ChannelImage(JSON: entry){
                    channelImages.append(attempt)
                }
                else{
                    traverseJSON(&channelImages, JSON: entry, complete: nil)
                }
            }
        }
        if complete != nil{
            complete!(channelImages: channelImages)
        }
    }

    func findInJSON(JSON:AnyObject, complete:((channelImages:[ChannelImage])->())?){
        var channelImages = [ChannelImage]()
        traverseJSON(&channelImages, JSON: JSON) { (channelImages) in
            if complete != nil{
                complete!(channelImages: channelImages)
            }
        }
    }

}

extension ChannelImage{
    var toJSON: [String:AnyObject] {
        var jsonObject = [String:AnyObject]()
        jsonObject["imageFormatId"] = self.imageFormatId
        jsonObject["imageId"] = self.imageId
        jsonObject["imageVerticalResolution"] = self.imageVerticalResolution
        jsonObject["objectType"] = self.objectType
        jsonObject["imageType"] = self.imageType
        jsonObject["objectId"] = self.objectId
        jsonObject["parentImageId"] = self.parentImageId
        jsonObject["imageURL"] = self.imageURL
        jsonObject["imageCreditDisplay"] = self.imageCreditDisplay
        jsonObject["imageCaption"] = self.imageCaption
        jsonObject["imageHorizontalResolution"] = self.imageHorizontalResolution
        jsonObject["lastUpdate"] = self.lastUpdate
        jsonObject["objectName"] = self.objectName
        jsonObject["imageTitle"] = self.imageTitle
        jsonObject["aspectRatio"] = self.aspectRatio

        if self.imageFormat != nil{
            jsonObject["imageFormat"] = self.imageFormat!
        }
        if self.imageExpiryDateTime != nil{
            jsonObject["imageExpiryDateTime"] = self.imageExpiryDateTime!
        }
        if self.imageOwner != nil{
            jsonObject["imageOwner"] = self.imageOwner!
        }
        if self.imageCredit != nil{
            jsonObject["imageCredit"] = self.imageCredit!
        }

        return jsonObject
    }

    var toJSONString: String {
        var jsonString = ""
        jsonString += ", \"imageFormatId\":\"\(self.imageFormatId)\""
        jsonString += ", \"imageId\":\"\(self.imageId)\""
        jsonString += ", \"imageVerticalResolution\":\"\(self.imageVerticalResolution)\""
        jsonString += ", \"objectType\":\"\(self.objectType)\""
        jsonString += ", \"imageType\":\"\(self.imageType)\""
        jsonString += ", \"objectId\":\"\(self.objectId)\""
        jsonString += ", \"parentImageId\":\"\(self.parentImageId)\""
        jsonString += ", \"imageURL\":\"\(self.imageURL)\""
        jsonString += ", \"imageCreditDisplay\":\"\(self.imageCreditDisplay)\""
        jsonString += ", \"imageCaption\":\"\(self.imageCaption)\""
        jsonString += ", \"imageHorizontalResolution\":\"\(self.imageHorizontalResolution)\""
        jsonString += ", \"lastUpdate\":\"\(self.lastUpdate)\""
        jsonString += ", \"objectName\":\"\(self.objectName)\""
        jsonString += ", \"imageTitle\":\"\(self.imageTitle)\""
        jsonString += ", \"aspectRatio\":\"\(self.aspectRatio)\""

        if self.imageFormat != nil{
            jsonString += ", \"imageFormat\":\"\(self.imageFormat!)\""
        }
        if self.imageExpiryDateTime != nil{
            jsonString += ", \"imageExpiryDateTime\":\"\(self.imageExpiryDateTime!)\""
        }
        if self.imageOwner != nil{
            jsonString += ", \"imageOwner\":\"\(self.imageOwner!)\""
        }
        if self.imageCredit != nil{
            jsonString += ", \"imageCredit\":\"\(self.imageCredit!)\""
        }

        jsonString = String(jsonString.characters.dropFirst()) //removes the ','
        jsonString = String(jsonString.characters.dropFirst()) //removes the beginning space

        return jsonString
    }
}

extension Array where Element:ChannelImage{
    var toJSONArray : [[String:AnyObject]]{
        var returnArray = [[String:AnyObject]]()
        for entry in self{
            returnArray.append(entry.toJSON)
        }
        return returnArray
    }

    var toJSONString : String{
        var returnString = ""
        for entry in self{
            returnString += entry.toJSONString
        }
        return returnString
    }
}

public class Airing{

    var sports = false
    var DSS = false
    var stereo = false
    var HDLevel = ""
    var seriesId : String? = nil
    var airingTime = ""
    var CC = false
    var subcategory : String? = nil
    var letterBox = false
    var HD = false
    var SAP = false
    var DVS = false
    var dolby = false
    var airingType = ""
    var duration = -1
    var category = ""
    var title = ""
    var episodeTitle : String? = nil
    var programId = ""
    var TVRating = ""
    var color = ""
    var movieRating : String? = nil


    init(){

    }

    init?(JSON:AnyObject?){
        var json = JSON
        if json != nil{
            if json is [String:AnyObject]{
                if let firstKey = (json as! [String:AnyObject]).keys.first{
                    if firstKey == "Airing"{
                        json = json![firstKey]
                    }
                }

                guard
                    let sports = json?["Sports"] as? Bool,
                    let DSS = json?["DSS"] as? Bool,
                    let stereo = json?["Stereo"] as? Bool,
                    let HDLevel = json?["HDLevel"] as? String,
                    let airingTime = json?["AiringTime"] as? String,
                    let CC = json?["CC"] as? Bool,
                    let letterBox = json?["LetterBox"] as? Bool,
                    let HD = json?["HD"] as? Bool,
                    let SAP = json?["SAP"] as? Bool,
                    let DVS = json?["DVS"] as? Bool,
                    let dolby = json?["Dolby"] as? Bool,
                    let airingType = json?["AiringType"] as? String,
                    let duration = json?["Duration"] as? Int,
                    let category = json?["Category"] as? String,
                    let title = json?["Title"] as? String,
                    let programId = json?["ProgramId"] as? String,
                    let TVRating = json?["TVRating"] as? String,
                    let color = json?["Color"] as? String
                else{
                    return nil
                }

                self.sports = sports
                self.DSS = DSS
                self.stereo = stereo
                self.HDLevel = HDLevel
                self.airingTime = airingTime
                self.CC = CC
                self.letterBox = letterBox
                self.HD = HD
                self.SAP = SAP
                self.DVS = DVS
                self.dolby = dolby
                self.airingType = airingType
                self.duration = duration
                self.category = category
                self.title = title
                self.programId = programId
                self.TVRating = TVRating
                self.color = color

                if let seriesId = json?["SeriesId"] as? String{
                    self.seriesId = seriesId
                }
                if let subcategory = json?["Subcategory"] as? String{
                    self.subcategory = subcategory
                }
                if let episodeTitle = json?["EpisodeTitle"] as? String{
                    self.episodeTitle = episodeTitle
                }
                if let movieRating = json?["MovieRating"] as? String{
                    self.movieRating = movieRating
                }


            }
            else{
                return nil
            }
        }
        else{
            return nil
        }
    }

    class func fromJSONArray(JSON:[[String:AnyObject]]) -> [Airing]{
        var returnArray = [Airing]()
        for entry in JSON{
            if let ent = Airing(JSON: entry){
                returnArray.append(ent)
            }
        }
        return returnArray
    }

    private func traverseJSON(inout airings:[Airing], JSON:AnyObject, complete:((airings:[Airing])->())?){
        if JSON is [String:AnyObject]{
            for (_,v) in (JSON as! [String:AnyObject]){
                if v is [String:AnyObject]{
                    if let attempt = Airing(JSON: v as! [String:AnyObject]){
                        airings.append(attempt)
                    }
                    traverseJSON(&airings, JSON: v as! [String:AnyObject], complete: nil)
                }
                else if v is [[String:AnyObject]]{
                    traverseJSON(&airings, JSON: v as! [[String:AnyObject]], complete: nil)
                }
            }
        }
        else if JSON is [[String:AnyObject]]{
            for entry in (JSON as! [[String:AnyObject]]){
                if let attempt = Airing(JSON: entry){
                    airings.append(attempt)
                }
                else{
                    traverseJSON(&airings, JSON: entry, complete: nil)
                }
            }
        }
        if complete != nil{
            complete!(airings: airings)
        }
    }

    func findInJSON(JSON:AnyObject, complete:((airings:[Airing])->())?){
        var airings = [Airing]()
        traverseJSON(&airings, JSON: JSON) { (airings) in
            if complete != nil{
                complete!(airings: airings)
            }
        }
    }

}

extension Airing{
    var toJSON: [String:AnyObject] {
        var jsonObject = [String:AnyObject]()
        jsonObject["sports"] = self.sports
        jsonObject["DSS"] = self.DSS
        jsonObject["stereo"] = self.stereo
        jsonObject["HDLevel"] = self.HDLevel
        jsonObject["airingTime"] = self.airingTime
        jsonObject["CC"] = self.CC
        jsonObject["letterBox"] = self.letterBox
        jsonObject["HD"] = self.HD
        jsonObject["SAP"] = self.SAP
        jsonObject["DVS"] = self.DVS
        jsonObject["dolby"] = self.dolby
        jsonObject["airingType"] = self.airingType
        jsonObject["duration"] = self.duration
        jsonObject["category"] = self.category
        jsonObject["title"] = self.title
        jsonObject["programId"] = self.programId
        jsonObject["TVRating"] = self.TVRating
        jsonObject["color"] = self.color

        if self.seriesId != nil{
            jsonObject["seriesId"] = self.seriesId!
        }
        if self.subcategory != nil{
            jsonObject["subcategory"] = self.subcategory!
        }
        if self.episodeTitle != nil{
            jsonObject["episodeTitle"] = self.episodeTitle!
        }
        if self.movieRating != nil{
            jsonObject["movieRating"] = self.movieRating!
        }

        return jsonObject
    }

    var toJSONString: String {
        var jsonString = ""
        jsonString += ", \"sports\":\"\(self.sports)\""
        jsonString += ", \"DSS\":\"\(self.DSS)\""
        jsonString += ", \"stereo\":\"\(self.stereo)\""
        jsonString += ", \"HDLevel\":\"\(self.HDLevel)\""
        jsonString += ", \"airingTime\":\"\(self.airingTime)\""
        jsonString += ", \"CC\":\"\(self.CC)\""
        jsonString += ", \"letterBox\":\"\(self.letterBox)\""
        jsonString += ", \"HD\":\"\(self.HD)\""
        jsonString += ", \"SAP\":\"\(self.SAP)\""
        jsonString += ", \"DVS\":\"\(self.DVS)\""
        jsonString += ", \"dolby\":\"\(self.dolby)\""
        jsonString += ", \"airingType\":\"\(self.airingType)\""
        jsonString += ", \"duration\":\"\(self.duration)\""
        jsonString += ", \"category\":\"\(self.category)\""
        jsonString += ", \"title\":\"\(self.title)\""
        jsonString += ", \"programId\":\"\(self.programId)\""
        jsonString += ", \"TVRating\":\"\(self.TVRating)\""
        jsonString += ", \"color\":\"\(self.color)\""

        if self.seriesId != nil{
            jsonString += ", \"seriesId\":\"\(self.seriesId!)\""
        }
        if self.subcategory != nil{
            jsonString += ", \"subcategory\":\"\(self.subcategory!)\""
        }
        if self.episodeTitle != nil{
            jsonString += ", \"episodeTitle\":\"\(self.episodeTitle!)\""
        }
        if self.movieRating != nil{
            jsonString += ", \"movieRating\":\"\(self.movieRating!)\""
        }

        jsonString = String(jsonString.characters.dropFirst()) //removes the ','
        jsonString = String(jsonString.characters.dropFirst()) //removes the beginning space

        return jsonString
    }
}

extension Array where Element:Airing{
    var toJSONArray : [[String:AnyObject]]{
        var returnArray = [[String:AnyObject]]()
        for entry in self{
            returnArray.append(entry.toJSON)
        }
        return returnArray
    }

    var toJSONString : String{
        var returnString = ""
        for entry in self{
            returnString += entry.toJSONString
        }
        return returnString
    }
}

public class SourceAttributeType{

    var sourceAttributeType = ""


    init(){

    }

    init?(JSON:AnyObject?){
        var json = JSON
        if json != nil{
            if json is [String:AnyObject]{
                if let firstKey = (json as! [String:AnyObject]).keys.first{
                    if firstKey == "SourceAttributeType"{
                        json = json![firstKey]
                    }
                }

                guard
                    let sourceAttributeType = json?["SourceAttributeType"] as? String
                else{
                    return nil
                }

                self.sourceAttributeType = sourceAttributeType


            }
            else{
                return nil
            }
        }
        else{
            return nil
        }
    }

    class func fromJSONArray(JSON:[[String:AnyObject]]) -> [SourceAttributeType]{
        var returnArray = [SourceAttributeType]()
        for entry in JSON{
            if let ent = SourceAttributeType(JSON: entry){
                returnArray.append(ent)
            }
        }
        return returnArray
    }

    private func traverseJSON(inout sourceAttributeTypes:[SourceAttributeType], JSON:AnyObject, complete:((sourceAttributeTypes:[SourceAttributeType])->())?){
        if JSON is [String:AnyObject]{
            for (_,v) in (JSON as! [String:AnyObject]){
                if v is [String:AnyObject]{
                    if let attempt = SourceAttributeType(JSON: v as! [String:AnyObject]){
                        sourceAttributeTypes.append(attempt)
                    }
                    traverseJSON(&sourceAttributeTypes, JSON: v as! [String:AnyObject], complete: nil)
                }
                else if v is [[String:AnyObject]]{
                    traverseJSON(&sourceAttributeTypes, JSON: v as! [[String:AnyObject]], complete: nil)
                }
            }
        }
        else if JSON is [[String:AnyObject]]{
            for entry in (JSON as! [[String:AnyObject]]){
                if let attempt = SourceAttributeType(JSON: entry){
                    sourceAttributeTypes.append(attempt)
                }
                else{
                    traverseJSON(&sourceAttributeTypes, JSON: entry, complete: nil)
                }
            }
        }
        if complete != nil{
            complete!(sourceAttributeTypes: sourceAttributeTypes)
        }
    }

    func findInJSON(JSON:AnyObject, complete:((sourceAttributeTypes:[SourceAttributeType])->())?){
        var sourceAttributeTypes = [SourceAttributeType]()
        traverseJSON(&sourceAttributeTypes, JSON: JSON) { (sourceAttributeTypes) in
            if complete != nil{
                complete!(sourceAttributeTypes: sourceAttributeTypes)
            }
        }
    }

}

extension SourceAttributeType{
    var toJSON: [String:AnyObject] {
        var jsonObject = [String:AnyObject]()
        jsonObject["sourceAttributeType"] = self.sourceAttributeType

        return jsonObject
    }

    var toJSONString: String {
        var jsonString = ""
        jsonString += ", \"sourceAttributeType\":\"\(self.sourceAttributeType)\""

        jsonString = String(jsonString.characters.dropFirst()) //removes the ','
        jsonString = String(jsonString.characters.dropFirst()) //removes the beginning space

        return jsonString
    }
}

extension Array where Element:SourceAttributeType{
    var toJSONArray : [[String:AnyObject]]{
        var returnArray = [[String:AnyObject]]()
        for entry in self{
            returnArray.append(entry.toJSON)
        }
        return returnArray
    }

    var toJSONString : String{
        var returnString = ""
        for entry in self{
            returnString += entry.toJSONString
        }
        return returnString
    }
}

