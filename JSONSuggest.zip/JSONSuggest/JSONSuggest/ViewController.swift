//
//  ViewController.swift
//  JSONSuggest
//
//  Created by Andrew Goodwin on 9/15/16.
//  Copyright © 2016 Andrew Goodwin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        if let path = NSBundle.mainBundle().pathForResource("person", ofType: "json")
          {
          do
          {
            let data = try NSData(contentsOfFile: path, options: .DataReadingMappedIfSafe)
            let json = try(NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions.MutableContainers))
            
            //var start = NSDate()
            JSONSuggest.sharedSuggest.isDebug = true
            //JSONSuggest.sharedSuggest.deliveryMethod = .Console
            JSONSuggest.sharedSuggest.singleFile = false
            JSONSuggest.sharedSuggest.includeSerialization = false
            JSONSuggest.sharedSuggest.makeSuggestions(json, root:"Person")
            
            //let gsrs = GridScheduleResult.fromJSONArray(json as! [[String : AnyObject]])
            //var end = NSDate()
            //var timeInterval: Double = end.timeIntervalSinceDate(start)
            
            //print("Time to make suggestions: \(timeInterval) seconds")
            
            //start = NSDate()
            
            /*let priority = DISPATCH_QUEUE_PRIORITY_DEFAULT
            dispatch_async(dispatch_get_global_queue(priority, 0)) {
                if let gsr = GridScheduleResult(JSON: json){
                    dispatch_async(dispatch_get_main_queue()) {
                        /if gsr.timeZones.count > 0{
                            print(gsr.timeZones.first!.startDateTime)
                        }
                        else{
                            print("no timezones found in gsr")
                        }
                        end = NSDate()
                        timeInterval = end.timeIntervalSinceDate(start)
                        
                        print("Time to parse everything: \(timeInterval) seconds")
                    }
                }
            }*/
            
            

            
            
            //start = NSDate()
            
            /*dispatch_async(dispatch_get_global_queue(priority, 0)) {
                Airing().findInJSON(json, complete: { (airings) in
                    if airings.count > 0{
                        dispatch_async(dispatch_get_main_queue()) {
                            print(airings.first!.category)
                            //print(airings.toJSONString)
                        }
                    }
                    else{
                        print("no airings found")
                    }
                    end = NSDate()
                    timeInterval = end.timeIntervalSinceDate(start)
                    
                    print("Time to find all airings: \(timeInterval) seconds")
                })
            }*/
            
          }
          catch
          {
                print("cannot read json file")
          }
        }
    }
    
    
    /*
 Is value a dictionary?
     if yes,
        create a class
        add class to list of suggestedClasses (SCs)
        for each key, value in it
            if value is simple object, add it as a property
            if value is an array of simple objects, add it as a property
            if value is an array of dictionaries, for the first entry in the array, create the class / add to SCs,
                set the properties for the class by the key / values, continue looking through objects to get more properties
     
     
 */
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

